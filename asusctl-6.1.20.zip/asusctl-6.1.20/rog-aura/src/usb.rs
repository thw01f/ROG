// Only these two packets must be 17 bytes
pub const AURA_LAPTOP_LED_APPLY: [u8; 17] = [
    0x5d, 0xb4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
];
pub const AURA_LAPTOP_LED_SET: [u8; 17] = [
    0x5d, 0xb5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
];
